#ifndef READER_H
#define READER_H

#include <string>

class Reader {
protected:
    std::string path_;

public:
    virtual ~Reader() = default;
    virtual void read(const std::string& path) = 0;
};

#endif