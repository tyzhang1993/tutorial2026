#include "Molecule.h"

void Molecule::addAtom(const Atom& atom) {
    atoms_.push_back(atom);
}

int Molecule::size() const {
    return static_cast<int>(atoms_.size());
}

const std::vector<Atom>& Molecule::getAtoms() const {
    return atoms_;
}

double Molecule::atomicMass(int Z) const {
    // amu
    switch (Z) {
        case 1:  return 1.00784;   // H
        case 6:  return 12.00000;  // C
        case 7:  return 14.00307;  // N
        case 8:  return 15.99491;  // O
        case 9:  return 18.99840;  // F
        case 15: return 30.97376;  // P
        case 16: return 31.97207;  // S
        case 17: return 34.96885;  // Cl
        default:
            throw std::runtime_error("Atomic mass not implemented for Z = " + std::to_string(Z));
    }
}

double Molecule::massOfAtomIndex(int atom_index) const {
    if (atom_index < 0 || atom_index >= size()) {
        throw std::out_of_range("Atom index out of range.");
    }
    return atomicMass(atoms_[atom_index].Z);
}

double Molecule::massOfCoordinateIndex(int coord_index) const {
    int atom_index = coord_index / 3;
    return massOfAtomIndex(atom_index);
}