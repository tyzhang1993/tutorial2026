#ifndef HESSIAN_READER_H
#define HESSIAN_READER_H

#include "Reader.h"
#include "Matrix.h"

class HessianReader : public Reader {
private:
    Matrix hessian_;

public:
    void read(const std::string& path) override;
    void read(const std::string& path, int expected_natoms);
    Matrix getHessian() const;
};

#endif