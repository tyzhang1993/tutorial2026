#ifndef JACOBI_DIAGONALIZER_H
#define JACOBI_DIAGONALIZER_H

#include "Diagonalizer.h"

class JacobiDiagonalizer : public Diagonalizer {
private:
    double tolerance_;
    int maxIterations_;

public:
    JacobiDiagonalizer(double tolerance = 1e-12, int maxIterations = 100000);

    void diagonalize(const Matrix& A,
                     std::vector<double>& eigenvalues,
                     Matrix& eigenvectors) override;
};

#endif