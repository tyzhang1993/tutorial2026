#ifndef MOLECULE_H
#define MOLECULE_H

#include <vector>
#include <stdexcept>
#include "Atom.h"

class Molecule {
private:
    std::vector<Atom> atoms_;

public:
    void addAtom(const Atom& atom);
    int size() const;
    const std::vector<Atom>& getAtoms() const;

    double atomicMass(int Z) const;
    double massOfAtomIndex(int atom_index) const;
    double massOfCoordinateIndex(int coord_index) const;
};

#endif