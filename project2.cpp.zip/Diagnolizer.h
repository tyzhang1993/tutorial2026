#ifndef DIAGONALIZER_H
#define DIAGONALIZER_H

#include <vector>
#include "Matrix.h"

class Diagonalizer {
public:
    virtual ~Diagonalizer() = default;

    virtual void diagonalize(const Matrix& A,
                             std::vector<double>& eigenvalues,
                             Matrix& eigenvectors) = 0;
};

#endif