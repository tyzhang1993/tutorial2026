#include "Matrix.h"
#include <iomanip>
#include <stdexcept>

Matrix::Matrix() : n_(0) {}

Matrix::Matrix(int n) : n_(n), data_(n, std::vector<double>(n, 0.0)) {}

int Matrix::size() const {
    return n_;
}

double& Matrix::operator()(int i, int j) {
    if (i < 0 || i >= n_ || j < 0 || j >= n_) {
        throw std::out_of_range("Matrix index out of range.");
    }
    return data_[i][j];
}

double Matrix::operator()(int i, int j) const {
    if (i < 0 || i >= n_ || j < 0 || j >= n_) {
        throw std::out_of_range("Matrix index out of range.");
    }
    return data_[i][j];
}

Matrix Matrix::identity(int n) {
    Matrix I(n);
    for (int i = 0; i < n; i++) {
        I(i, i) = 1.0;
    }
    return I;
}

void Matrix::print() const {
    for (int i = 0; i < n_; i++) {
        for (int j = 0; j < n_; j++) {
            std::cout << std::setw(14) << data_[i][j] << " ";
        }
        std::cout << "\n";
    }
}