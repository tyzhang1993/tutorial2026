#include "HessianReader.h"
#include <fstream>
#include <stdexcept>

void HessianReader::read(const std::string& path) {
    read(path, -1);
}

void HessianReader::read(const std::string& path, int expected_natoms) {
    path_ = path;

    std::ifstream fin(path);
    if (!fin) {
        throw std::runtime_error("Failed to open Hessian file: " + path);
    }

    int natoms;
    fin >> natoms;
    if (!fin || natoms <= 0) {
        throw std::runtime_error("Invalid Hessian file format.");
    }

    if (expected_natoms != -1 && natoms != expected_natoms) {
        throw std::runtime_error("Geometry/Hessian atom count mismatch.");
    }

    int dim = 3 * natoms;
    hessian_ = Matrix(dim);

    for (int i = 0; i < dim; i++) {
        for (int j = 0; j < dim; j++) {
            fin >> hessian_(i, j);
            if (!fin) {
                throw std::runtime_error("Failed while reading Hessian matrix.");
            }
        }
    }
}

Matrix HessianReader::getHessian() const {
    return hessian_;
}