#ifndef GEOMETRY_READER_H
#define GEOMETRY_READER_H

#include "Reader.h"
#include "Molecule.h"

class GeometryReader : public Reader {
private:
    Molecule molecule_;

public:
    void read(const std::string& path) override;
    Molecule getMolecule() const;
};

#endif