#include "VibrationalAnalysis.h"
#include <cmath>
#include <iostream>

VibrationalAnalysis::VibrationalAnalysis(const Molecule& molecule, const Matrix& hessian)
    : molecule_(molecule), hessian_(hessian), massWeightedHessian_(hessian.size()), eigenvectors_(hessian.size()) {}

void VibrationalAnalysis::buildMassWeightedHessian() {
    int dim = hessian_.size();

    for (int i = 0; i < dim; i++) {
        for (int j = 0; j < dim; j++) {
            double mi = molecule_.massOfCoordinateIndex(i);
            double mj = molecule_.massOfCoordinateIndex(j);
            massWeightedHessian_(i, j) = hessian_(i, j) / std::sqrt(mi * mj);
        }
    }
}

void VibrationalAnalysis::solve(Diagonalizer& diagonalizer) {
    diagonalizer.diagonalize(massWeightedHessian_, eigenvalues_, eigenvectors_);
}

std::vector<double> VibrationalAnalysis::computeFrequenciesCmInverse() const {
    std::vector<double> freqs;
    const double conversion = 5140.48; // sqrt(Eh/(a0^2 amu)) -> cm^-1

    for (double lambda : eigenvalues_) {
        if (lambda < 0.0) {
            freqs.push_back(-conversion * std::sqrt(std::fabs(lambda))); 
        } else {
            freqs.push_back(conversion * std::sqrt(lambda));
        }
    }
    return freqs;
}

const Matrix& VibrationalAnalysis::getMassWeightedHessian() const {
    return massWeightedHessian_;
}

const std::vector<double>& VibrationalAnalysis::getEigenvalues() const {
    return eigenvalues_;
}