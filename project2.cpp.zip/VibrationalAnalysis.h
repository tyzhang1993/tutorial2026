#ifndef VIBRATIONAL_ANALYSIS_H
#define VIBRATIONAL_ANALYSIS_H

#include <vector>
#include "Molecule.h"
#include "Matrix.h"
#include "Diagonalizer.h"

class VibrationalAnalysis {
private:
    Molecule molecule_;
    Matrix hessian_;
    Matrix massWeightedHessian_;
    std::vector<double> eigenvalues_;
    Matrix eigenvectors_;

public:
    VibrationalAnalysis(const Molecule& molecule, const Matrix& hessian);

    void buildMassWeightedHessian();
    void solve(Diagonalizer& diagonalizer);
    std::vector<double> computeFrequenciesCmInverse() const;

    const Matrix& getMassWeightedHessian() const;
    const std::vector<double>& getEigenvalues() const;
};

#endif