#ifndef ATOM_H
#define ATOM_H

struct Atom {
    int Z;
    double x;
    double y;
    double z;

    Atom(int atomic_number = 0, double x_ = 0.0, double y_ = 0.0, double z_ = 0.0)
        : Z(atomic_number), x(x_), y(y_), z(z_) {}
};

#endif