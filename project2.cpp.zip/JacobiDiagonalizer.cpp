#include "JacobiDiagonalizer.h"
#include <cmath>
#include <stdexcept>
#include <algorithm>

JacobiDiagonalizer::JacobiDiagonalizer(double tolerance, int maxIterations)
    : tolerance_(tolerance), maxIterations_(maxIterations) {}

void JacobiDiagonalizer::diagonalize(const Matrix& A,
                                     std::vector<double>& eigenvalues,
                                     Matrix& eigenvectors) {
    int n = A.size();
    Matrix D = A;
    eigenvectors = Matrix::identity(n);

    for (int iter = 0; iter < maxIterations_; iter++) {
        int p = 0, q = 1;
        double maxOffDiag = 0.0;

        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (std::fabs(D(i, j)) > maxOffDiag) {
                    maxOffDiag = std::fabs(D(i, j));
                    p = i;
                    q = j;
                }
            }
        }

        if (maxOffDiag < tolerance_) {
            break;
        }

        double app = D(p, p);
        double aqq = D(q, q);
        double apq = D(p, q);

        double tau = (aqq - app) / (2.0 * apq);
        double t = (tau >= 0.0)
                 ? 1.0 / (tau + std::sqrt(1.0 + tau * tau))
                 : -1.0 / (-tau + std::sqrt(1.0 + tau * tau));

        double c = 1.0 / std::sqrt(1.0 + t * t);
        double s = t * c;

        for (int k = 0; k < n; k++) {
            if (k != p && k != q) {
                double dkp = D(k, p);
                double dkq = D(k, q);

                D(k, p) = c * dkp - s * dkq;
                D(p, k) = D(k, p);

                D(k, q) = s * dkp + c * dkq;
                D(q, k) = D(k, q);
            }
        }

        double new_app = c * c * app - 2.0 * s * c * apq + s * s * aqq;
        double new_aqq = s * s * app + 2.0 * s * c * apq + c * c * aqq;

        D(p, p) = new_app;
        D(q, q) = new_aqq;
        D(p, q) = 0.0;
        D(q, p) = 0.0;

        for (int k = 0; k < n; k++) {
            double vip = eigenvectors(k, p);
            double viq = eigenvectors(k, q);

            eigenvectors(k, p) = c * vip - s * viq;
            eigenvectors(k, q) = s * vip + c * viq;
        }

        if (iter == maxIterations_ - 1) {
            throw std::runtime_error("Jacobi diagonalization did not converge.");
        }
    }

    eigenvalues.resize(n);
    for (int i = 0; i < n; i++) {
        eigenvalues[i] = D(i, i);
    }

    // sort eigenvalues ascending, and reorder eigenvectors columns
    std::vector<int> idx(n);
    for (int i = 0; i < n; i++) idx[i] = i;

    std::sort(idx.begin(), idx.end(),
              [&](int a, int b) { return eigenvalues[a] < eigenvalues[b]; });

    std::vector<double> sortedVals(n);
    Matrix sortedVecs(n);

    for (int col = 0; col < n; col++) {
        sortedVals[col] = eigenvalues[idx[col]];
        for (int row = 0; row < n; row++) {
            sortedVecs(row, col) = eigenvectors(row, idx[col]);
        }
    }

    eigenvalues = sortedVals;
    eigenvectors = sortedVecs;
}