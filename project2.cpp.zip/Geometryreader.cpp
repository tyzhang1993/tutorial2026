#include "GeometryReader.h"
#include <fstream>
#include <iostream>
#include <stdexcept>

void GeometryReader::read(const std::string& path) {
    path_ = path;
    molecule_ = Molecule();

    std::ifstream fin(path);
    if (!fin) {
        throw std::runtime_error("Failed to open geometry file: " + path);
    }

    int natoms;
    fin >> natoms;

    if (!fin || natoms <= 0) {
        throw std::runtime_error("Invalid geometry file format.");
    }

    for (int i = 0; i < natoms; i++) {
        int Z;
        double x, y, z;
        fin >> Z >> x >> y >> z;
        if (!fin) {
            throw std::runtime_error("Failed while reading geometry file.");
        }
        molecule_.addAtom(Atom(Z, x, y, z));
    }
}

Molecule GeometryReader::getMolecule() const {
    return molecule_;
}